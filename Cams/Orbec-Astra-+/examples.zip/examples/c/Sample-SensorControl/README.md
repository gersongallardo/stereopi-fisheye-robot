# C sensor control

Function description: Demonstrate Device control operations
