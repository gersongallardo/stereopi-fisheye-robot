# C++ CommonUsages sample

This example demonstrates obtaining video streams and common parameter settings.