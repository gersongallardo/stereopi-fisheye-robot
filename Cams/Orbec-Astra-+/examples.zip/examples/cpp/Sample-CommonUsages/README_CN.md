# C++ CommonUsages 示例

该示例演示获取视频流和常用的参数设置。