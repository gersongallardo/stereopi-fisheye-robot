# Orbbec SDK driver

OrbbecSDK Because the library files, depth engine and driver files, are dedicated code, do not belong to the mit protocol.  driver license reference misc/driver/license
