var searchData=
[
  ['config_0',['Config',['../classob_1_1StreamProfile.html#ac3da7e21a05bf8852638db7e4dd1b81a',1,'ob::StreamProfile']]],
  ['context_1',['Context',['../classob_1_1DeviceInfo.html#ac26c806e60ca4a0547680edb68f6e39b',1,'ob::DeviceInfo']]],
  ['coordinatetransformhelper_2',['CoordinateTransformHelper',['../classob_1_1Device.html#a4bed2fe813d6c793ff9dadd249133dab',1,'ob::Device::CoordinateTransformHelper'],['../classob_1_1Frame.html#a4bed2fe813d6c793ff9dadd249133dab',1,'ob::Frame::CoordinateTransformHelper']]]
];
