var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz~",
  1: "abcdefghinoprstv",
  2: "o",
  3: "cdefmoprstuv",
  4: "acdefghilmnopqrstuvw~",
  5: "abcdefghiklmnoprstuwxyz",
  6: "bdfglmopst",
  7: "ou",
  8: "adefhosu",
  9: "cdfoprs",
  10: "_defiot",
  11: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

