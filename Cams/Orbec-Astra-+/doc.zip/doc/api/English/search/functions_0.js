var searchData=
[
  ['accelframe_0',['AccelFrame',['../classob_1_1AccelFrame.html#a4a4959a6268a677788d4584a19f7d26c',1,'ob::AccelFrame::AccelFrame(Frame &amp;frame)'],['../classob_1_1AccelFrame.html#a0497ee5a617e3c1407e79051a99f26e0',1,'ob::AccelFrame::AccelFrame(std::unique_ptr&lt; FrameImpl &gt; impl)']]],
  ['accelstreamprofile_1',['AccelStreamProfile',['../classob_1_1AccelStreamProfile.html#ad1037c14505bce1a90145cdd9579889b',1,'ob::AccelStreamProfile::AccelStreamProfile(StreamProfile &amp;profile)'],['../classob_1_1AccelStreamProfile.html#aca8e4d3f1bb11e7a4923d8b9fd37186e',1,'ob::AccelStreamProfile::AccelStreamProfile(std::unique_ptr&lt; StreamProfileImpl &gt; impl)']]],
  ['activateauthorization_2',['activateAuthorization',['../classob_1_1Device.html#a2bec58d49565ad02b7951907fb71ee2c',1,'ob::Device']]],
  ['align_3',['Align',['../classob_1_1Align.html#ad4763c53aaeaea07051e8281e5335187',1,'ob::Align']]],
  ['as_4',['as',['../classob_1_1Filter.html#a39c73b99195b88000d7e87829be2d3a3',1,'ob::Filter::as()'],['../classob_1_1Frame.html#a4d909b4f194efc37909e48b1e2aac551',1,'ob::Frame::as()'],['../classob_1_1StreamProfile.html#aab836b566d9b6fada8c5ed78b0000226',1,'ob::StreamProfile::as()']]],
  ['asicname_5',['asicName',['../classob_1_1DeviceInfo.html#a5ff3ee803502b471d3ff3a9f27fea522',1,'ob::DeviceInfo']]]
];
