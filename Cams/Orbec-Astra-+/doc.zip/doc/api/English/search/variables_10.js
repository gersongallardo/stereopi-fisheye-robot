var searchData=
[
  ['scalemisalignment_0',['scaleMisalignment',['../structOBAccelIntrinsic.html#a4df4b6d3b6c32ff0bfe28e7af4f6427c',1,'OBAccelIntrinsic::scaleMisalignment'],['../structOBGyroIntrinsic.html#a4c28199aad7e270b8b01e059097309ae',1,'OBGyroIntrinsic::scaleMisalignment']]],
  ['sequence_5fname_1',['sequence_name',['../structHDR__CONFIG.html#abfe46f1b827959fa521e70c5f4f4e3b8',1,'HDR_CONFIG']]],
  ['sequenceselectid_2',['sequenceSelectId',['../structOBSequenceIdItem.html#aaf68fd366f52e144a6c30b2a9da22ed9',1,'OBSequenceIdItem']]],
  ['size_3',['size',['../structOBDataChunk.html#af80b0059d918467b6b58e56b798c8ad1',1,'OBDataChunk::size'],['../structOBSpatialFastFilterParams.html#af81b1456ed9bd592f5db230437d1fe6f',1,'OBSpatialFastFilterParams::size'],['../structOBSpatialModerateFilterParams.html#a31ee784cadfb7c4519d975fc0e185a1a',1,'OBSpatialModerateFilterParams::size']]],
  ['status_4',['status',['../structob__error.html#afc2451cf30a6e060b284e38ec60c2993',1,'ob_error']]],
  ['step_5',['step',['../structOBIntPropertyRange.html#a01e6e87553be91eaff2ac559eb114f94',1,'OBIntPropertyRange::step'],['../structOBFloatPropertyRange.html#ae67f00fcb8e7a103b749835a0e0cbaa5',1,'OBFloatPropertyRange::step'],['../structOBUint16PropertyRange.html#a9b8f44727363292d3c98c8fdda390da2',1,'OBUint16PropertyRange::step'],['../structOBUint8PropertyRange.html#aa194063572042e15f7c8ab1d35140651',1,'OBUint8PropertyRange::step'],['../structOBBoolPropertyRange.html#ac3fa21c03a908853058b4ab33451fb22',1,'OBBoolPropertyRange::step']]],
  ['syncmode_6',['syncMode',['../structOBDeviceSyncConfig.html#a19078aa83a64a13f659613811f27b152',1,'OBDeviceSyncConfig::syncMode'],['../structob__multi__device__sync__config.html#a8cc39ed5db27676bdf5cffcb5ccbed67',1,'ob_multi_device_sync_config::syncMode']]]
];
