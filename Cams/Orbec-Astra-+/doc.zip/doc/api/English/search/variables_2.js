var searchData=
[
  ['checksum_0',['checksum',['../structOBDepthWorkMode.html#a3d7dbf9351ce403fcae1e502fcfc1d33',1,'OBDepthWorkMode']]],
  ['chipbottomtemp_1',['chipBottomTemp',['../structOBDeviceTemperature.html#a3054e79cde62f8c8083614daf62d6b47',1,'OBDeviceTemperature']]],
  ['chiptoptemp_2',['chipTopTemp',['../structOBDeviceTemperature.html#af75f06b38dcd78edc5fec267b8c02ac2',1,'OBDeviceTemperature']]],
  ['cmdversion_3',['cmdVersion',['../structOBDataBundle.html#a680a947cb52f7a64ec0aa17b4bfe2d9c',1,'OBDataBundle']]],
  ['coeffs_4',['coeffs',['../structOBCameraAlignIntrinsic.html#a9f3d911e179f2d3c630b30f2e9cdf374',1,'OBCameraAlignIntrinsic']]],
  ['colordelayus_5',['colorDelayUs',['../structob__multi__device__sync__config.html#aa5909e5e5238eb9c5cfe8261561c38fd',1,'ob_multi_device_sync_config']]],
  ['cputemp_6',['cpuTemp',['../structOBDeviceTemperature.html#afa6b196156fd9b4b85a33e332440bc6a',1,'OBDeviceTemperature']]],
  ['cur_7',['cur',['../structOBIntPropertyRange.html#acae2aaab07f2cc2a2842f1e602765a7b',1,'OBIntPropertyRange::cur'],['../structOBFloatPropertyRange.html#a0196dc2692726aeafc9718f5988b1ec8',1,'OBFloatPropertyRange::cur'],['../structOBUint16PropertyRange.html#a662b642815c91042fa9e9461ec99dda6',1,'OBUint16PropertyRange::cur'],['../structOBUint8PropertyRange.html#a7280633bdf7aa3578dab4b463421cd11',1,'OBUint8PropertyRange::cur'],['../structOBBoolPropertyRange.html#a6aec56bfe29835e89fa5607e3bf04ce8',1,'OBBoolPropertyRange::cur']]],
  ['cx_8',['cx',['../structOBCameraIntrinsic.html#a50b429aad5b3819aec089b154cea6297',1,'OBCameraIntrinsic']]],
  ['cy_9',['cy',['../structOBCameraIntrinsic.html#a6f6b987279f103e7843dc1fd9caa369f',1,'OBCameraIntrinsic']]]
];
