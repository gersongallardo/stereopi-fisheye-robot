var searchData=
[
  ['value_0',['value',['../classob_1_1AccelFrame.html#a0908897067c5aabb38bbd801457704d1',1,'ob::AccelFrame::value()'],['../classob_1_1GyroFrame.html#a7e5148cc718c854e1f2f241a21e9a5c4',1,'ob::GyroFrame::value()']]],
  ['version_1',['Version',['../classob_1_1Version.html',1,'ob']]],
  ['version_2eh_2',['Version.h',['../Version_8h.html',1,'']]],
  ['version_2ehpp_3',['Version.hpp',['../Version_8hpp.html',1,'']]],
  ['vid_4',['vid',['../classob_1_1DeviceInfo.html#acebee531439d2da2434ef3d550f93d43',1,'ob::DeviceInfo::vid()'],['../classob_1_1DeviceList.html#a74f6a148c7b47321f4fae8d1f558fa45',1,'ob::DeviceList::vid()']]],
  ['videoframe_5',['VideoFrame',['../classob_1_1VideoFrame.html',1,'ob::VideoFrame'],['../classob_1_1VideoFrame.html#ac2c91e13715a3a2fca61c1c4cb46cd20',1,'ob::VideoFrame::VideoFrame(Frame &amp;frame)'],['../classob_1_1VideoFrame.html#a2f34519bb165d320c9cf2ce1863670d5',1,'ob::VideoFrame::VideoFrame(std::unique_ptr&lt; FrameImpl &gt; impl)']]],
  ['videostreamprofile_6',['VideoStreamProfile',['../classob_1_1VideoStreamProfile.html',1,'ob::VideoStreamProfile'],['../classob_1_1VideoStreamProfile.html#af90398015aee0e5b2ca4e2c417f91e6f',1,'ob::VideoStreamProfile::VideoStreamProfile(StreamProfile &amp;profile)'],['../classob_1_1VideoStreamProfile.html#a47c0c5c6795c51484c29545186f82f3a',1,'ob::VideoStreamProfile::VideoStreamProfile(std::unique_ptr&lt; StreamProfileImpl &gt; impl)']]]
];
