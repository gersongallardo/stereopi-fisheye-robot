var searchData=
[
  ['name_0',['name',['../structOBDepthWorkMode.html#a3d869051a5fb201a042fa33135fcfb6b',1,'OBDepthWorkMode::name'],['../structOBSequenceIdItem.html#adf06395b270625506aa034093d26bc99',1,'OBSequenceIdItem::name'],['../structOBPropertyItem.html#aec9d6c8b5815e77ca57e407a5be5b285',1,'OBPropertyItem::name']]],
  ['noisedensity_1',['noiseDensity',['../structOBAccelIntrinsic.html#a97c4dc2a14287549cc9681fb8a2bf265',1,'OBAccelIntrinsic::noiseDensity'],['../structOBGyroIntrinsic.html#ac6dbd7cf491e40022b70107532569a6c',1,'OBGyroIntrinsic::noiseDensity']]]
];
