var searchData=
[
  ['data_0',['data',['../structOBDataChunk.html#a259bca37ce7de4c8ccfb53d6dd9eef16',1,'OBDataChunk::data'],['../structOBDataBundle.html#ac88e7834ff571269c27a4bf9f9b0b79f',1,'OBDataBundle::data']]],
  ['datasize_1',['dataSize',['../structOBDataBundle.html#a894e264e761bfcea31c96e9d19b0876e',1,'OBDataBundle']]],
  ['def_2',['def',['../structOBIntPropertyRange.html#a1e805ffd6e3a0749bbbf96334673d260',1,'OBIntPropertyRange::def'],['../structOBFloatPropertyRange.html#a999993d4ee54185981e537e9fb931018',1,'OBFloatPropertyRange::def'],['../structOBUint16PropertyRange.html#af912ed7187857d6d6f9ea1b79a0cfe7b',1,'OBUint16PropertyRange::def'],['../structOBUint8PropertyRange.html#a5d9cdb82c8e9a76c9063ac7cd9fc5614',1,'OBUint8PropertyRange::def'],['../structOBBoolPropertyRange.html#a0172fa01e9d98f366a14648f19865699',1,'OBBoolPropertyRange::def']]],
  ['depthdelayus_3',['depthDelayUs',['../structob__multi__device__sync__config.html#a0413ddb90e90b291e14544c38d88a697',1,'ob_multi_device_sync_config']]],
  ['depthdistortion_4',['depthDistortion',['../structOBCameraParam.html#ae6e904b125b297f70aeae248efb5fe38',1,'OBCameraParam::depthDistortion'],['../structOBCameraParam__V0.html#a9c236538df64a0a19116c9ca19dbe456',1,'OBCameraParam_V0::depthDistortion']]],
  ['depthintrinsic_5',['depthIntrinsic',['../structOBCameraParam.html#ae19c6de2bef4c15b282ea14614546629',1,'OBCameraParam::depthIntrinsic'],['../structOBCameraParam__V0.html#ae123d678ab0873314da19778983ca28b',1,'OBCameraParam_V0::depthIntrinsic']]],
  ['deviceid_6',['deviceId',['../structOBDeviceSyncConfig.html#a793d1603876f061fc3ab0c26131e73ff',1,'OBDeviceSyncConfig']]],
  ['devicetriggersignaloutdelay_7',['deviceTriggerSignalOutDelay',['../structOBDeviceSyncConfig.html#acd2b333bb455fc6c6a716e16ae6e8bba',1,'OBDeviceSyncConfig']]],
  ['devicetriggersignaloutpolarity_8',['deviceTriggerSignalOutPolarity',['../structOBDeviceSyncConfig.html#a5e36a59f45da629155068a69dc8d7959',1,'OBDeviceSyncConfig']]],
  ['dhcp_9',['dhcp',['../structOBNetIpConfig.html#a3de2c46f23cb239f849d0b3a3fabc337',1,'OBNetIpConfig']]],
  ['disp_5fdiff_10',['disp_diff',['../structOBSpatialAdvancedFilterParams.html#a62db60d63fa61beed9c930c61b6b17e3',1,'OBSpatialAdvancedFilterParams::disp_diff'],['../structOBSpatialModerateFilterParams.html#a448151fde47a0040dba3f4e2125c92ae',1,'OBSpatialModerateFilterParams::disp_diff'],['../structOBNoiseRemovalFilterParams.html#a72f5863e10769e3e4332277206893db3',1,'OBNoiseRemovalFilterParams::disp_diff']]],
  ['distortion_11',['distortion',['../structOBCalibrationParam.html#ab7bf5f50e9aa26ba9cd2710685bd5628',1,'OBCalibrationParam']]]
];
