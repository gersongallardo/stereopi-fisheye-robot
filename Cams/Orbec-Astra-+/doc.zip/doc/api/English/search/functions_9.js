var searchData=
[
  ['metadata_0',['metadata',['../classob_1_1Frame.html#a6f3b254af45d7aafe9fbd2176470d689',1,'ob::Frame']]],
  ['metadatasize_1',['metadataSize',['../classob_1_1Frame.html#a92fc147ea74990dece08fbc6097c9b1e',1,'ob::Frame']]]
];
