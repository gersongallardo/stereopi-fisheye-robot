var searchData=
[
  ['rawphaseframe_0',['RawPhaseFrame',['../classob_1_1RawPhaseFrame.html#a483957bd9a64e96134eadb2cdb01022f',1,'ob::RawPhaseFrame::RawPhaseFrame(Frame &amp;frame)'],['../classob_1_1RawPhaseFrame.html#a313ec4ab4c3f93b44724246b54f8c68f',1,'ob::RawPhaseFrame::RawPhaseFrame(std::unique_ptr&lt; FrameImpl &gt; impl)']]],
  ['readahb_1',['readAHB',['../classob_1_1Device.html#a635a8e05753a59500c092d0e127d2b3a',1,'ob::Device']]],
  ['readcustomerdata_2',['readCustomerData',['../classob_1_1Device.html#a33ea10323fe7e482fa58fa8925aa6eeb',1,'ob::Device']]],
  ['readflash_3',['readFlash',['../classob_1_1Device.html#ab7726384f7d51bd80124c0d3de505e99',1,'ob::Device']]],
  ['readi2c_4',['readI2C',['../classob_1_1Device.html#a1bb47c0b13611b7dd00e3ffbcee21aec',1,'ob::Device']]],
  ['reboot_5',['reboot',['../classob_1_1Device.html#a9abc8db448a8181e2cf5849f3dea75dd',1,'ob::Device::reboot()'],['../classob_1_1Device.html#a6370104afd5044074c8a0069816ac156',1,'ob::Device::reboot(uint32_t delayMs)']]],
  ['recorder_6',['Recorder',['../classob_1_1Recorder.html#a441e0cde1c82080e273e3041b2772715',1,'ob::Recorder::Recorder()'],['../classob_1_1Recorder.html#abf5d5e3c9fd714e0c66bde7d4f0e068e',1,'ob::Recorder::Recorder(std::unique_ptr&lt; RecorderImpl &gt; impl)'],['../classob_1_1Recorder.html#acd66ed40058948c71a9cee852f357a17',1,'ob::Recorder::Recorder(std::shared_ptr&lt; Device &gt; device)']]],
  ['reset_7',['reset',['../classob_1_1Filter.html#aedb9c713b865dba8d0ae96a85737390d',1,'ob::Filter']]],
  ['resetdefaultdepthfilterconfig_8',['resetDefaultDepthFilterConfig',['../classob_1_1Device.html#a7c673fdd82aa383d34b5f252ec24f75a',1,'ob::Device']]]
];
