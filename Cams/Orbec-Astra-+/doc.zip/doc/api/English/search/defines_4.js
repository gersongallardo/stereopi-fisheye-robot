var searchData=
[
  ['is_5fir_5fframe_0',['is_ir_frame',['../ObTypes_8h.html#a52307266a1ca005dea6d7bfdb3ccfbb1',1,'ObTypes.h']]],
  ['is_5fir_5fsensor_1',['is_ir_sensor',['../ObTypes_8h.html#ac1b4daef79e8a8397f52a942f498cd83',1,'ObTypes.h']]],
  ['is_5fir_5fstream_2',['is_ir_stream',['../ObTypes_8h.html#a5435c1aa7d509966d116971db508f303',1,'ObTypes.h']]],
  ['isirframe_3',['isIRFrame',['../ObTypes_8h.html#aabb66472b1e9671d71c8485b939fabb1',1,'ObTypes.h']]],
  ['isirsensor_4',['isIRSensor',['../ObTypes_8h.html#a042d71df32e7c35791f4ea02c2b39b74',1,'ObTypes.h']]],
  ['isirstream_5',['isIRStream',['../ObTypes_8h.html#aef6685c44da8eac31e856f397de1afd3',1,'ObTypes.h']]]
];
