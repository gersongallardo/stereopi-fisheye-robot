var searchData=
[
  ['r_0',['r',['../structOBColorPoint.html#afe48bc5c44ced94fc3e9bde3653ba5fb',1,'OBColorPoint']]],
  ['radius_1',['radius',['../structOBSpatialAdvancedFilterParams.html#ad5ba7e142440fe36767062b1813ff3a2',1,'OBSpatialAdvancedFilterParams']]],
  ['randomwalk_2',['randomWalk',['../structOBAccelIntrinsic.html#a913d5d1229786cd69f358b504ccd0246',1,'OBAccelIntrinsic::randomWalk'],['../structOBGyroIntrinsic.html#a2043610fbcc23df252d8c34fdbc294dc',1,'OBGyroIntrinsic::randomWalk']]],
  ['referencetemp_3',['referenceTemp',['../structOBAccelIntrinsic.html#ab2685e781b607c920c96a4dc38cada3f',1,'OBAccelIntrinsic::referenceTemp'],['../structOBGyroIntrinsic.html#ae5313bbaa4af7e397d15f877e28a720b',1,'OBGyroIntrinsic::referenceTemp']]],
  ['reserved_4',['reserved',['../structDISP__OFFSET__CONFIG.html#ab3a75f862110f4c294a053a0e96b48cb',1,'DISP_OFFSET_CONFIG']]],
  ['rgbdistortion_5',['rgbDistortion',['../structOBCameraParam.html#a0629e0ee848fc0b6a1ded5ac64166235',1,'OBCameraParam::rgbDistortion'],['../structOBCameraParam__V0.html#a8d49ffcb10562873b29c60864e512474',1,'OBCameraParam_V0::rgbDistortion']]],
  ['rgbintrinsic_6',['rgbIntrinsic',['../structOBCameraParam.html#acc6d8df18c5216e8e1bd6188ed68d47e',1,'OBCameraParam::rgbIntrinsic'],['../structOBCameraParam__V0.html#a9f9eeb405b3c19bc1c9422ae32474f7d',1,'OBCameraParam_V0::rgbIntrinsic']]],
  ['rgbtemp_7',['rgbTemp',['../structOBDeviceTemperature.html#af3e639159fffb2171c01381db38527e8',1,'OBDeviceTemperature']]],
  ['rgbtriggersignalindelay_8',['rgbTriggerSignalInDelay',['../structOBDeviceSyncConfig.html#a004e403a03bc62458a6f7809d5463e51',1,'OBDeviceSyncConfig']]],
  ['rot_9',['rot',['../structOBD2CTransform.html#a9b8da8c82da9e03b92299e6816a963d1',1,'OBD2CTransform']]]
];
