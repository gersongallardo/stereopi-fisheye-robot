var searchData=
[
  ['name_0',['name',['../classob_1_1DeviceInfo.html#a51343c5f5983c7cfc85acd9242cbf187',1,'ob::DeviceInfo::name()'],['../classob_1_1DeviceList.html#a110f4f9e911c093e4342c8b4e713ff27',1,'ob::DeviceList::name()']]],
  ['noiseremovalfilter_1',['NoiseRemovalFilter',['../classob_1_1NoiseRemovalFilter.html#ac0262726a88aa7064a30f119ea9c15b0',1,'ob::NoiseRemovalFilter']]]
];
