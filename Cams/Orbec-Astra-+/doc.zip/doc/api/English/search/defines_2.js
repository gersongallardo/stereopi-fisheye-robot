var searchData=
[
  ['enablemultidevicesync_0',['enableMultiDeviceSync',['../Context_8hpp.html#a77befc5d9971137cb6980f723461e52c',1,'Context.hpp']]]
];
