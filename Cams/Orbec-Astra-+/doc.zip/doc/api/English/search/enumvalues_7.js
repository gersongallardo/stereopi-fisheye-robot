var searchData=
[
  ['uvc_5fbackend_5fauto_0',['UVC_BACKEND_AUTO',['../ObTypes_8h.html#ada3b6440b004eaa13e11f338fb005a82af09c8d265aabaec959e03a04cd926515',1,'ObTypes.h']]],
  ['uvc_5fbackend_5flibuvc_1',['UVC_BACKEND_LIBUVC',['../ObTypes_8h.html#ada3b6440b004eaa13e11f338fb005a82a42643f1d3d35e6ea2fdc805d81dfc663',1,'ObTypes.h']]],
  ['uvc_5fbackend_5fv4l2_2',['UVC_BACKEND_V4L2',['../ObTypes_8h.html#ada3b6440b004eaa13e11f338fb005a82acc840fe1bf8df4a79820ecacd0f880ba',1,'ObTypes.h']]]
];
