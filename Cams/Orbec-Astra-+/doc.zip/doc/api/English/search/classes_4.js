var searchData=
[
  ['edgenoiseremovalfilter_0',['EdgeNoiseRemovalFilter',['../classob_1_1EdgeNoiseRemovalFilter.html',1,'ob']]],
  ['error_1',['Error',['../classob_1_1Error.html',1,'ob']]]
];
