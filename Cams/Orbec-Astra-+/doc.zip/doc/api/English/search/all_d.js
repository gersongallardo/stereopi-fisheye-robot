var searchData=
[
  ['name_0',['name',['../structOBDepthWorkMode.html#a3d869051a5fb201a042fa33135fcfb6b',1,'OBDepthWorkMode::name'],['../structOBSequenceIdItem.html#adf06395b270625506aa034093d26bc99',1,'OBSequenceIdItem::name'],['../structOBPropertyItem.html#aec9d6c8b5815e77ca57e407a5be5b285',1,'OBPropertyItem::name'],['../classob_1_1DeviceInfo.html#a51343c5f5983c7cfc85acd9242cbf187',1,'ob::DeviceInfo::name()'],['../classob_1_1DeviceList.html#a110f4f9e911c093e4342c8b4e713ff27',1,'ob::DeviceList::name()']]],
  ['noisedensity_1',['noiseDensity',['../structOBAccelIntrinsic.html#a97c4dc2a14287549cc9681fb8a2bf265',1,'OBAccelIntrinsic::noiseDensity'],['../structOBGyroIntrinsic.html#ac6dbd7cf491e40022b70107532569a6c',1,'OBGyroIntrinsic::noiseDensity']]],
  ['noiseremovalfilter_2',['NoiseRemovalFilter',['../classob_1_1NoiseRemovalFilter.html#ac0262726a88aa7064a30f119ea9c15b0',1,'ob::NoiseRemovalFilter::NoiseRemovalFilter()'],['../classob_1_1NoiseRemovalFilter.html',1,'ob::NoiseRemovalFilter']]]
];
