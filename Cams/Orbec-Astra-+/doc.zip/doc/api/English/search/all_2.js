var searchData=
[
  ['b_0',['b',['../structOBColorPoint.html#a479d6d154f5d673c41b3197ff708fd22',1,'OBColorPoint']]],
  ['baseline_1',['baseline',['../structBASELINE__CALIBRATION__PARAM.html#a94c00a31d7ff90eaaf9d84e4f1e95932',1,'BASELINE_CALIBRATION_PARAM']]],
  ['baseline_5fcalibration_5fparam_2',['BASELINE_CALIBRATION_PARAM',['../structBASELINE__CALIBRATION__PARAM.html',1,'']]],
  ['bias_3',['bias',['../structOBAccelIntrinsic.html#a394dc459a50aa3fd03de9570293975e2',1,'OBAccelIntrinsic::bias'],['../structOBGyroIntrinsic.html#aa7bc8a5c9a7df2dd9785392fb4788968',1,'OBGyroIntrinsic::bias']]],
  ['bufferdestroycallback_4',['BufferDestroyCallback',['../namespaceob.html#aa530dba90a807bee70473e2ddd46f582',1,'ob']]]
];
