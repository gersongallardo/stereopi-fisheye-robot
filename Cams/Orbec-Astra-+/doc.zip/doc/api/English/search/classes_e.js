var searchData=
[
  ['temporalfilter_0',['TemporalFilter',['../classob_1_1TemporalFilter.html',1,'ob']]],
  ['thresholdfilter_1',['ThresholdFilter',['../classob_1_1ThresholdFilter.html',1,'ob']]]
];
