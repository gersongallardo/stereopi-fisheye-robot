var searchData=
[
  ['querydevicelist_0',['queryDeviceList',['../classob_1_1Context.html#a4ce3502d4b87dccc0304790507b04615',1,'ob::Context']]]
];
