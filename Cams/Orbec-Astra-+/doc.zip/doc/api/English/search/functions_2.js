var searchData=
[
  ['data_0',['data',['../classob_1_1Frame.html#ab01f260e6b83387a1f219964a5642089',1,'ob::Frame']]],
  ['datasize_1',['dataSize',['../classob_1_1Frame.html#a15aa7ffde185af68c920e17aaf0b9131',1,'ob::Frame']]],
  ['decimationfilter_2',['DecimationFilter',['../classob_1_1DecimationFilter.html#ab2866996406e45e4225857812ccd58a6',1,'ob::DecimationFilter']]],
  ['decompressionfilter_3',['DecompressionFilter',['../classob_1_1DecompressionFilter.html#ae016b289099f2df8e60d653572256a37',1,'ob::DecompressionFilter']]],
  ['depthframe_4',['DepthFrame',['../classob_1_1DepthFrame.html#a2ba14d4912b0aea80348a909a00f4fd1',1,'ob::DepthFrame::DepthFrame(Frame &amp;frame)'],['../classob_1_1DepthFrame.html#abd6a36d80258577ecff3b68852382fed',1,'ob::DepthFrame::DepthFrame(std::unique_ptr&lt; FrameImpl &gt; impl)']]],
  ['depthframe_5',['depthFrame',['../classob_1_1FrameSet.html#a4d0b1a2cb11e13fdc476b30491eff0d1',1,'ob::FrameSet']]],
  ['device_6',['Device',['../classob_1_1Device.html#a0cd5f7d083d5ccf908596303f9cfdd2b',1,'ob::Device::Device(Device &amp;&amp;device)'],['../classob_1_1Device.html#a4bbc101b3b034fda60a903b1e72719f5',1,'ob::Device::Device(std::unique_ptr&lt; DeviceImpl &gt; impl)']]],
  ['devicecount_7',['deviceCount',['../classob_1_1DeviceList.html#ada4e95ac534b1d072cba42f5a492c97b',1,'ob::DeviceList']]],
  ['deviceinfo_8',['DeviceInfo',['../classob_1_1DeviceInfo.html#a378453e2eaa8d140ef51125f9856b63e',1,'ob::DeviceInfo']]],
  ['devicelist_9',['DeviceList',['../classob_1_1DeviceList.html#a78325a6d57af6744915cb4dd75e295ab',1,'ob::DeviceList']]],
  ['devicepresetlist_10',['DevicePresetList',['../classob_1_1DevicePresetList.html#a88f8f6c5bf2a717ec78a6a10fc312c14',1,'ob::DevicePresetList']]],
  ['devicetype_11',['deviceType',['../classob_1_1DeviceInfo.html#ab35f5fc3e8050fa49ad8d72b1474b0b3',1,'ob::DeviceInfo']]],
  ['deviceupgrade_12',['deviceUpgrade',['../classob_1_1Device.html#ab2bd8a9f47d3fe9bb7be0b173b2cab7d',1,'ob::Device']]],
  ['deviceupgradefromdata_13',['deviceUpgradeFromData',['../classob_1_1Device.html#a6f0f110f2ef0edeba0bf776241878580',1,'ob::Device']]],
  ['disableallstream_14',['disableAllStream',['../classob_1_1Config.html#ad03b2517ffaca641ce78978a5f7e8b0d',1,'ob::Config']]],
  ['disableframesync_15',['disableFrameSync',['../classob_1_1Pipeline.html#ad46ea763b174c240b15279208b9e3d4c',1,'ob::Pipeline']]],
  ['disablestream_16',['disableStream',['../classob_1_1Config.html#a5e3fcf7f5a0efc7b928409c19dd03dc9',1,'ob::Config']]],
  ['disparitytransform_17',['DisparityTransform',['../classob_1_1DisparityTransform.html#ab9dccbc48518e6873662ce0e170adce4',1,'ob::DisparityTransform']]]
];
