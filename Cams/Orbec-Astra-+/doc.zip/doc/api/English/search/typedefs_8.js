var searchData=
[
  ['sendfilecallback_0',['SendFileCallback',['../Types_8hpp.html#af4ed1a1867e655fa5e4b77e646f080a4',1,'Types.hpp']]],
  ['setdatacallback_1',['SetDataCallback',['../Types_8hpp.html#a55032b39d9a625cc1b43684765ad46b1',1,'Types.hpp']]]
];
