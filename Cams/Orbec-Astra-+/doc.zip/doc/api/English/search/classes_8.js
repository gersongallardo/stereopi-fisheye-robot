var searchData=
[
  ['irframe_0',['IRFrame',['../classob_1_1IRFrame.html',1,'ob']]]
];
