var searchData=
[
  ['deprecated_0',['DEPRECATED',['../ObTypes_8h.html#ac1e8a42306d8e67cb94ca31c3956ee78',1,'ObTypes.h']]]
];
