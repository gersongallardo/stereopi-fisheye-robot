var searchData=
[
  ['data_5ftran_5ferr_5fbusy_0',['DATA_TRAN_ERR_BUSY',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baac1efa1c6f7ecd1a949d62990b860948f',1,'ObTypes.h']]],
  ['data_5ftran_5ferr_5fother_1',['DATA_TRAN_ERR_OTHER',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa751db98bb767fb6f87ab746622b93f84',1,'ObTypes.h']]],
  ['data_5ftran_5ferr_5ftran_5ffailed_2',['DATA_TRAN_ERR_TRAN_FAILED',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa0df375c9f6f18c024fa8c26538fbe14b',1,'ObTypes.h']]],
  ['data_5ftran_5ferr_5funsupported_3',['DATA_TRAN_ERR_UNSUPPORTED',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa93b77ce9a8e24a0895711fc034ef407e',1,'ObTypes.h']]],
  ['data_5ftran_5ferr_5fverify_5ffailed_4',['DATA_TRAN_ERR_VERIFY_FAILED',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa8251d042431da7718ea00467b88a685d',1,'ObTypes.h']]],
  ['data_5ftran_5fstat_5fdone_5',['DATA_TRAN_STAT_DONE',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa9f2189d6788db3646b5bfe8d9eb60c78',1,'ObTypes.h']]],
  ['data_5ftran_5fstat_5fstopped_6',['DATA_TRAN_STAT_STOPPED',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baaf765cc6979299e18db590afe65849d56',1,'ObTypes.h']]],
  ['data_5ftran_5fstat_5ftransferring_7',['DATA_TRAN_STAT_TRANSFERRING',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa6de978ed0db340c507a24404e9f87839',1,'ObTypes.h']]],
  ['data_5ftran_5fstat_5fverify_5fdone_8',['DATA_TRAN_STAT_VERIFY_DONE',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baae2970c224ccd0228c8345d5709cbdaef',1,'ObTypes.h']]],
  ['data_5ftran_5fstat_5fverifying_9',['DATA_TRAN_STAT_VERIFYING',['../ObTypes_8h.html#a3923c2ae80aefbd2943bd89286c6b3baa584114511a41c57a6dd3648af136ee3c',1,'ObTypes.h']]],
  ['depth_5fcropping_5fmode_5fauto_10',['DEPTH_CROPPING_MODE_AUTO',['../ObTypes_8h.html#a5b2b481f1a71132f1621e49da6b4748fa1edd66fad4a50a96ee6bcde9c6e88ab9',1,'ObTypes.h']]],
  ['depth_5fcropping_5fmode_5fclose_11',['DEPTH_CROPPING_MODE_CLOSE',['../ObTypes_8h.html#a5b2b481f1a71132f1621e49da6b4748fa9cedb9bf206021b07082430939fc85f0',1,'ObTypes.h']]],
  ['depth_5fcropping_5fmode_5fopen_12',['DEPTH_CROPPING_MODE_OPEN',['../ObTypes_8h.html#a5b2b481f1a71132f1621e49da6b4748fa8a060556a09f3e3561fe6af099d69a20',1,'ObTypes.h']]]
];
