var searchData=
[
  ['hp_5fstatus_5fcontrol_5ftransfer_5ffailed_0',['HP_STATUS_CONTROL_TRANSFER_FAILED',['../ObTypes_8h.html#a30a00b26730789f292d4bca95ae5f84baa307827455872ed79ed301ae3d3ceddb',1,'ObTypes.h']]],
  ['hp_5fstatus_5fno_5fdevice_5ffound_1',['HP_STATUS_NO_DEVICE_FOUND',['../ObTypes_8h.html#a30a00b26730789f292d4bca95ae5f84bac77af199642c2a39d581dbce083a2b8a',1,'ObTypes.h']]],
  ['hp_5fstatus_5fok_2',['HP_STATUS_OK',['../ObTypes_8h.html#a30a00b26730789f292d4bca95ae5f84ba29b47da6dd264cf88f0b7f92f86c0d95',1,'ObTypes.h']]],
  ['hp_5fstatus_5funknown_5ferror_3',['HP_STATUS_UNKNOWN_ERROR',['../ObTypes_8h.html#a30a00b26730789f292d4bca95ae5f84bad00ef08661137c972c7683460a7e5ab9',1,'ObTypes.h']]]
];
