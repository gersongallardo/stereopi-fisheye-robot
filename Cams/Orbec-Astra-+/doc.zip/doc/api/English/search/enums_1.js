var searchData=
[
  ['uvc_5fbackend_0',['UVC_BACKEND',['../ObTypes_8h.html#ada3b6440b004eaa13e11f338fb005a82',1,'ObTypes.h']]]
];
