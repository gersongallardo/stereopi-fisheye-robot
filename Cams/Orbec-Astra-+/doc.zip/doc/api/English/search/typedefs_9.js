var searchData=
[
  ['tof_5fexposure_5fthreshold_5fcontrol_0',['TOF_EXPOSURE_THRESHOLD_CONTROL',['../ObTypes_8h.html#adfeca2238eac37d7af37739b809dab7c',1,'ObTypes.h']]],
  ['tof_5ffilter_5frange_1',['TOF_FILTER_RANGE',['../ObTypes_8h.html#a626d4bb43871e60deab25d777bddb57a',1,'ObTypes.h']]]
];
