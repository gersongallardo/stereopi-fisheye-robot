var searchData=
[
  ['noiseremovalfilter_0',['NoiseRemovalFilter',['../classob_1_1NoiseRemovalFilter.html',1,'ob']]]
];
