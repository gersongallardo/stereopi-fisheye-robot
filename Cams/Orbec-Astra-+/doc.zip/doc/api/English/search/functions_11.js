var searchData=
[
  ['uid_0',['uid',['../classob_1_1DeviceInfo.html#a102db5355a8f1b702c2f50d6a9a5bce3',1,'ob::DeviceInfo::uid()'],['../classob_1_1DeviceList.html#a7636b3fca3e41d867103d3e29e4f2e7a',1,'ob::DeviceList::uid()']]],
  ['usbtype_1',['usbType',['../classob_1_1DeviceInfo.html#ac686ddc32b6ff3ee06c9bcfa189dfd40',1,'ob::DeviceInfo']]]
];
