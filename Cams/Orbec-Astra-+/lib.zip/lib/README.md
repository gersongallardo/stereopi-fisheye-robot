# Orbbec SDK library

This Directory contains the Orbbec SDK library, depth engine and drivers files. Those files are close source now and will be open source in the near future.

The license for those files can be found in the LICENSE file in the root directory of the Orbbec SDK repository.
